package a3psc;

public class Pessoa {
    /* --------- ATRIBUTOS --------- */
    private String nome;
    private long cpf;
    private String endereco;
    private long telefone;

    /* ------- MÉTODOS CONSTRUTORES ------- */

    public Pessoa(String nome, long cpf,String dataNascimento, String endereco, long telefone){
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
        this.telefone = telefone;
    }

    /* -------- OUTROS MÉTODOS -------- */
     
}
